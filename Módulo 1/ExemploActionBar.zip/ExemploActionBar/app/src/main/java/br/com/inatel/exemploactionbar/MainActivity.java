package br.com.inatel.exemploactionbar;

import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ListView lvPaises;
    private ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvPaises = (ListView) findViewById(R.id.lv_dados);
        adapter = new ArrayAdapter<>(getBaseContext(), android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.paises));
        lvPaises.setAdapter(adapter);

        ActionBar mActionBar = getSupportActionBar();
        mActionBar.setDisplayShowHomeEnabled(true);
        mActionBar.setLogo(R.drawable.ic_app);
        mActionBar.setDisplayUseLogoEnabled(true);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

       getMenuInflater().inflate(R.menu.menu_action, menu);

       SearchView mSearchView = new SearchView(this);

        MenuItem menuItemSearch = menu.findItem(R.id.action_search);
        menuItemSearch.setActionView(mSearchView);

         mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Log.d("LogSearchView", "Texto onQueryTextSubmit " + query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Log.d("LogSearchView", "Texto onQueryTextChange " + newText);
                adapter.getFilter().filter(newText.toString());
                return false;
            }
        });


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.action_info)
            Toast.makeText(getBaseContext(), "Clicou em Informações, faça alguma coisa!", Toast.LENGTH_LONG).show();

        return super.onOptionsItemSelected(item);
    }


}
