package br.com.inatel.exemplomysql;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class NewProductActivity extends AppCompatActivity {

    JSONParser jsonParser = new JSONParser();
    EditText txtName, txtPrice, txtDescription;
    private Button btnNewProduct;
    private ProgressDialog pDialog;

    Product productEditable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_product);


        txtName = (EditText) findViewById(R.id.txtName);
        txtPrice = (EditText) findViewById(R.id.txtPrice);
        txtDescription = (EditText) findViewById(R.id.txtDescription);

        btnNewProduct = (Button) findViewById(R.id.btnNewProduct);
        btnNewProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                productEditable.setName(txtName.getText().toString());
                productEditable.setDescription(txtDescription.getText().toString());
                productEditable.setPrice(Double.parseDouble(txtPrice.getText().toString()));

                if (productEditable.getPid() == 0)
                    new CreateNewProduct().execute(productEditable);
                else
                    new SaveProductDetails().execute(productEditable);
            }
        });


        //Pega a intent que carrega o produto
        Intent i = getIntent();

        //pega o produto que foi carregado como parâmetro
        productEditable = (Product) i.getSerializableExtra("productSelected");

        if (productEditable != null) {
            txtName.setText(productEditable.getName());
            txtDescription.setText(productEditable.getDescription());
            txtPrice.setText(String.valueOf(productEditable.getPrice()));
            btnNewProduct.setText("EDITAR");
        } else {

            productEditable = new Product();
        }

    }

    /**
     * Background Async Task para Criar uma nova tarefa
     */
    class CreateNewProduct extends AsyncTask<Product, String, String> {

        /**
         * Antes de iniciar o processamento da tarefa, será apresentado o Progress Dialog.
         */

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(NewProductActivity.this);
            pDialog.setMessage("Criando Novo Produto ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        /**
         * Criando um produto
         */
        protected String doInBackground(Product... args) {

            JSONObject json = new JSONObject();

            Product produto = new Product();
            produto = args[0];


            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("name", produto.getName().toString()));
            params.add(new BasicNameValuePair("price", String.valueOf(produto.getPrice())));
            params.add(new BasicNameValuePair("description", produto.getDescription().toString()));

            // criando produto com o método HTTP POST
            json = jsonParser.makeHttpRequest(Url_Utils.url_new_product,
                    "POST", params);
            //Checagem da Resposta na janela de Log
            Log.d("Create New Product", json.toString());

            // check for success tag
            try {
                int success = json.getInt(Url_Utils.TAG_SUCCESS);

                if (success == 1) {
                    //Produto criado com sucesso
                    Intent i = getIntent(); //Retorna a Intent que startou esse Activity
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    setResult(100, i);
                    finish();
                } else {
                    // failed to create product
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        /**
         * Depois de completar a tarefa, o Progress Dialog será fechado
         **/
        protected void onPostExecute(String file_url) {
            //Tarefa concluida, dismiss() dispensa o Progress Dialog
            pDialog.dismiss();

            AlertDialog.Builder builder = new AlertDialog.Builder(NewProductActivity.this);
            builder.setMessage("Produto adicionado com sucesso")
                    .setTitle("Novo Produto");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }

    }


    /**
     * Background Async Task para Salvar Produtos
     */
    class SaveProductDetails extends AsyncTask<Product, String, String> {

        /**
         * Antes de iniciar a Thread in background, será apresentado o Progress Dialog
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(NewProductActivity.this);
            pDialog.setMessage("Salvando o Producto...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        /**
         * Salvando Produto
         */
        protected String doInBackground(Product... args) {


            Product produto = new Product();
            produto = args[0];

            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair(Url_Utils.TAG_PID, String.valueOf(produto.getPid())));
            params.add(new BasicNameValuePair(Url_Utils.TAG_NAME, produto.getName()));
            params.add(new BasicNameValuePair(Url_Utils.TAG_PRICE, String.valueOf(produto.getPrice())));
            params.add(new BasicNameValuePair(Url_Utils.TAG_DETAILS, produto.getDescription()));

            // Envia dados modificados para utilizando HTTP Resquest
            //utiliza da url de uppate para enviar um requisição http do tipo post
            JSONObject json = jsonParser.makeHttpRequest(Url_Utils.url_update_product,
                    "POST", params);

            // check json success tag
            try {
                int success = json.getInt(Url_Utils.TAG_SUCCESS);

                if (success == 1) {
                    //sucesso no update
                    //Fecha a activity e solicita a abertura novament, result code 100 para notificar a necessidade de update
                    Intent i = getIntent();
                    setResult(100, i);
                    finish();
                } else {
                    //falha em realizar o update, o desenvolvedor poderá realizar alguma tarefa
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        /**
         * Depois de completar a tarefa, fechar o Progress Dialog.
         **/
        protected void onPostExecute(String file_url) {
            pDialog.dismiss();
        }
    }


}
