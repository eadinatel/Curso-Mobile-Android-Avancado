package br.com.inatel.exemplomysql;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

/**
 * Created by rafael.liberato on 15/03/2017.
 */

public class RecyclerViewAdapter extends RecyclerView.Adapter {

    private List<Product> productList;
    private Context ctx;
    private ItemLongClickListener onLongClickListener;

    public RecyclerViewAdapter(List<Product> productList, Context ctx) {
        this.productList = productList;
        this.ctx = ctx;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(ctx)
                .inflate(R.layout.item_product, parent, false);

        MyViewHolder myViewHolder = new MyViewHolder(view);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        MyViewHolder myViewHolder = (MyViewHolder) holder;
        Product product = productList.get(position);
        myViewHolder.name.setText(product.getName().toString());

    }

    public void setOnLongClickListener(ItemLongClickListener itemLongClickListener) {
        this.onLongClickListener = itemLongClickListener;
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnLongClickListener {

        final TextView name;
        final ImageView img_overflow;

        public MyViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.item_product_name);
            img_overflow = (ImageView) itemView.findViewById(R.id.img_overflow);

            //Imagem icone 3 pontinhos do RecyclerView
            img_overflow.setOnLongClickListener(this);
        }

        @Override
        public boolean onLongClick(View v) {

            if (onLongClickListener != null)
                onLongClickListener.onLongClick(v, productList.get(getAdapterPosition()),  productList.get(getAdapterPosition()).getPid());

            return false;
        }
    }


    public interface ItemLongClickListener {
        void onLongClick(View v, Product product, int pid);
    }
}
