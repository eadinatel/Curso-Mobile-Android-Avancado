package br.com.inatel.exemplomysql;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by rafael.liberato on 14/03/2017.
 */

public class Product implements Serializable {

    private int pid;
    private String name;
    private double price;
    private String description;

    public Product(String id, String name, String description, String price) {

        this.name = name;
        this.pid = Integer.parseInt(id);
        this.description = description;
        this.price = Double.parseDouble(price);
    }

    public Product() {

    }


    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
