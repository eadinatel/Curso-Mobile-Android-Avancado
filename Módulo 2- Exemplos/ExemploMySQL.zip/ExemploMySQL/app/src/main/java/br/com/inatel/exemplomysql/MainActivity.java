package br.com.inatel.exemplomysql;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.UiThread;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuPopupHelper;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RecyclerViewAdapter.
        ItemLongClickListener {

    JSONParser jParser = new JSONParser();
    List<Product> productList;

    JSONArray products = null;
    RecyclerView recyclerView;
    RecyclerViewAdapter adapter;
    private ProgressDialog pDialog;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //Se o requestCode for igual a 100, a aplicação deverá realizar um refresh na Activity
        if (requestCode == 100) {
            refreshActivy();
        }
    }

    private void refreshActivy() {
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(new Intent(getBaseContext(), NewProductActivity.class));
                startActivityForResult(intent, 100);
            }
        });


        recyclerView = (RecyclerView) findViewById(R.id.myRecyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);


        productList = new ArrayList<>();

        new LoadAllProducts().execute();


    }

    @Override
    public void onLongClick(View v, final Product productSelected, final int pid) {
        Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        /**
         * A variável pattern, representa um padrão de comportamento, onde os parâmetros são:
         *   { Start without a delay ,   Vibrate for 100 milliseconds , Sleep for 1000 milliseconds
         */
        long[] pattern = {0, 100, 100};
        vb.vibrate(pattern, -1);//padrão e repetição. -1 significa sem repetição


        PopupMenu popup = new PopupMenu(v.getContext(), v);
        popup.inflate(R.menu.menu_item_recyclerview);
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.action_item_details:
                        new GetProductDetails().execute(String.valueOf(pid));
                        break;
                    case R.id.action_item_excluir:
                        new DeleteProduct().execute(String.valueOf(pid));
                        break;
                    case R.id.action_item_editar:
                        // Criação da intenção de navegação
                        Intent in = new Intent(getApplicationContext(),
                                NewProductActivity.class);
                        //envia o "pid - identificação do produto" como parâmetros
                        in.putExtra("productSelected", productSelected);

                        //inicia uma nova activity e aguarda um resultado, resposta de feedback
                        startActivityForResult(in, 100);
                        break;

                }

                return false;
            }
        });
        popup.show();


    }

    /***
     * Background Async Task para carregar todos os produtos
     */
    class LoadAllProducts extends AsyncTask<String, String, String> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Carregando produtos. Por favor, aguarde ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();

        }


        //Carrega todos os produtos
        @Override
        protected String doInBackground(String... strings) {


            List<NameValuePair> params = new ArrayList<>();

            JSONObject json = jParser.makeHttpRequest(Url_Utils.url_get_all_products, "GET", params);

            Log.d("Todos os Produtos", json.toString());

            try {

                //Checagem TAG
                int success = json.getInt(Url_Utils.TAG_SUCCESS);

                if (success == 1) {

                    products = json.getJSONArray(Url_Utils.TAG_PRODUCT);

                    for (int i = 0; i < products.length(); i++) {

                        JSONObject c = products.getJSONObject(i);

                        String id = c.getString(Url_Utils.TAG_PID);
                        String name = c.getString(Url_Utils.TAG_NAME);
                        String description = c.getString(Url_Utils.TAG_DETAILS);
                        String price = c.getString(Url_Utils.TAG_PRICE);

                        productList.add(new Product(id, name, description, price));

                    }
                } else {

                    Log.d("TELA PRINCIPAL", "Nenhum produto encontrado no Banco de Dados");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }


            return null;
        }

        //Depois de executar a Thread Background
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);


            adapter = new RecyclerViewAdapter(productList, MainActivity.this);

            recyclerView.setAdapter(adapter);


            recyclerView.invalidate();
            adapter.notifyDataSetChanged();

            adapter.setOnLongClickListener(MainActivity.this);

            pDialog.dismiss();


        }

    }

    /***
     * Background Async Task para deletar produtos
     */
    class DeleteProduct extends AsyncTask<String, String, String> {

        /**
         * Antes de iniciar a tarefa em background, será executardo o Progress Dialog.
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Deletando Produto...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        /**
         * Deletando Produto
         */
        protected String doInBackground(String... args) {

            // Check for success tag
            int success;
            try {

                //Building Parameters
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("pid", args[0]));

                //Deleta o produto com base no ID utilizando HTTP POST request
                JSONObject json = jParser.makeHttpRequest(
                        Url_Utils.url_delete_product, "POST", params);

                //Log json response
                Log.d("Delete Product", json.toString());

                //json success tag
                success = json.getInt(Url_Utils.TAG_SUCCESS);
                if (success == 1) {
                    //produto deletado com sucesso, finaliza esta activity e abre novamente, porém, sem o elemento deletado
                    Intent i = getIntent();
                    setResult(100, i);
                    finish();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        /**
         * Depois de completo a background task, dispensar o Progress Dialog
         **/
        protected void onPostExecute(String file_url) {

            pDialog.dismiss();
            refreshActivy();
        }

    }


    /**
     * Background Async Task para pegar os detalhes dos produtos
     */
    class GetProductDetails extends AsyncTask<String, String, String> {

        /**
         * Antes de iniciar a tarefa em background, será executardo o Progress Dialog.
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Loading product details. Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        /**
         * Pega os detalhes do produto em background thread
         */
        protected String doInBackground(String... args) {

            final String pid = args[0];

            //tag para verificação do sucesso da operação
            int success;
            try {

                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("pid", pid));

                //Pega os detalhes do objeto com base no ID, utiliza-se do HTTP GET request
                JSONObject json = jParser.makeHttpRequest(
                        Url_Utils.url_product_details, "GET", params);

                //Log response
                Log.d("Detalhe do Produto", json.toString());

                //json success tag
                success = json.getInt(Url_Utils.TAG_SUCCESS);
                if (success == 1) {
                    //produto recebido com sucesso
                    JSONArray productObj = json
                            .getJSONArray("product"); // JSON Array

                    //pega o primeiro objeto do JSON ARRAY, neste caso, será um objeto do tipo produto
                    final JSONObject product = productObj.getJSONObject(0);


                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Toast.makeText(MainActivity.this, "Detalhes " +
                                        product.getString(Url_Utils.TAG_DETAILS), Toast.LENGTH_SHORT).show();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });


                } else {
                    // Produto sem PID "identificação"
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }


            return null;
        }

        /**
         * Depois de completo a background task, dispensar o Progress Dialog
         **/
        protected void onPostExecute(String file_url) {
            pDialog.dismiss();
        }
    }


}
