package br.com.inatel.exemplomysql;

/**
 * Created by rafael.liberato on 15/03/2017.
 */

public class Url_Utils {

    public static final String url_new_product = "http://eadinatelandroid.tk/create_product.php";
    public static final String url_get_all_products = "http://eadinatelandroid.tk/get_all_products.php" ;
    public static final String url_delete_product = "http://eadinatelandroid.tk/delete_product.php";
    public static final String url_product_details = "http://eadinatelandroid.tk/get_product_details.php";
    public static final String url_update_product = "http://eadinatelandroid.tk/update_product.php";


    public static final String TAG_SUCCESS = "success";
    public static final String TAG_PRODUCT = "products";
    public static final String TAG_PID = "pid";
    public static final String TAG_NAME = "name";
    public static final String TAG_DETAILS = "description";
    public static final String TAG_PRICE = "price";

}
