package br.com.inatel.exemplopersistencia;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import java.util.List;
import br.com.inatel.exemplopersistencia.dao.ContatoDAO;
import br.com.inatel.exemplopersistencia.modelo.Contato;

public class ListaActivity extends AppCompatActivity {

    private SharedPreferences pref;
    private ListView lvContatos;
    private Button btnNovoContato;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        carregaThema();

        setContentView(R.layout.activity_lista);

        btnNovoContato = (Button) findViewById(R.id.btnNovoContato);

        lvContatos = (ListView) findViewById(R.id.lvContatos);
        lvContatos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                //Ao clicar em um novo contato, A classe Contato deverá implementar Seriazeble
                Contato contato = (Contato) lvContatos.getItemAtPosition(i);
                Intent intentFormulario = new Intent(getBaseContext(), FormularioActivity.class);
                intentFormulario.putExtra("contato", contato);
                startActivity(intentFormulario);
            }
        });


        btnNovoContato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentFormulario = new Intent(getBaseContext(), FormularioActivity.class);
                startActivity(intentFormulario);
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        carregaLista();
    }

    private void carregaThema() {
        pref = getSharedPreferences("NomeDoArquivoPreferences", Context.MODE_PRIVATE);
        if (pref != null) {
            Utils.setTheme(pref.getInt("SETTINGS_THEME_COLOR", 0));  //Set the stored theme, will default to Black
            Utils.onActivityCreateSetTheme(this);
        }
    }

    private void carregaLista() {
        ContatoDAO dao = new ContatoDAO(this);
        List<Contato> contatos = dao.buscarContatos();
        dao.close();

        ArrayAdapter<Contato> adapter = new ArrayAdapter<Contato>(this, android.R.layout.simple_list_item_1, contatos);
        lvContatos.setAdapter(adapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_personalizado, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.btn_menu_settings:

                startActivityForResult(new Intent(getBaseContext(), SettingsActivity.class), 10);
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 10) {

            Utils.changeToTheme(this, pref.getInt("SETTINGS_THEME_COLOR", 0));
        }
    }


}
