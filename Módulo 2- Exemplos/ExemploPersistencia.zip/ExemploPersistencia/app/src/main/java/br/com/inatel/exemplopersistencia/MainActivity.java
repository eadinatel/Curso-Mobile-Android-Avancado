package br.com.inatel.exemplopersistencia;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import br.com.inatel.exemplopersistencia.dao.ContatoDAO;
import br.com.inatel.exemplopersistencia.modelo.Contato;

public class MainActivity extends AppCompatActivity {

    private EditText txtEmail, txtPass;
    private Button btnLogin, btnRegister;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.LoginTheme);
        setContentView(R.layout.activity_main);

        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtPass = (EditText) findViewById(R.id.txtPass);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnRegister = (Button) findViewById(R.id.btnRegister);
//Redirecionar o usuário para tela de Registro.

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                List<Contato> contatos = new ContatoDAO(getBaseContext()).buscarContatos();
                for (Contato contato : contatos) {

                    if(contato.getEmail().equals(txtEmail.getText().toString()) &&
                            contato.getPassword() == Integer.parseInt(txtPass.getText().toString())){

                        startActivity(new Intent(getBaseContext(), ListaActivity.class));
                    }else{
                        Toast.makeText(MainActivity.this, "Dados Inválidos", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getBaseContext(), FormularioActivity.class).putExtra("register", true));
            }
        });

    }
}
