package br.com.inatel.exemplopersistencia;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class SettingsActivity extends AppCompatActivity {

    int colorTheme = Utils.DEFAULT; // Cor Default, padrão será o inteiro de numero 3
    private RadioButton rbRed, rbGreen, rbBlue, rbDefault;
    private RadioGroup rbGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final SharedPreferences pref = getSharedPreferences("NomeDoArquivoPreferences", Context.MODE_PRIVATE);
        if (pref != null) {
            colorTheme = pref.getInt("SETTINGS_THEME_COLOR", Utils.DEFAULT); // Utils.Default retorna um inteiro que representa a cor default
            Utils.setTheme(colorTheme); //Seta a cor armazenada em Shared Preferences
            Utils.onActivityCreateSetTheme(this);
        }

        setContentView(R.layout.activity_settings);
        rbGroup = (RadioGroup) findViewById(R.id.rbGroup);
        rbRed = (RadioButton) findViewById(R.id.rbRed);
        rbGreen = (RadioButton) findViewById(R.id.rbGreen);
        rbBlue = (RadioButton) findViewById(R.id.rbBlue);
        rbDefault = (RadioButton) findViewById(R.id.rbDefault);


        switch (colorTheme) {
            case Utils.RED:
                rbRed.setChecked(true);
                break;
            case Utils.GREEN:
                rbGreen.setChecked(true);
                break;
            case Utils.BLUE:
                rbBlue.setChecked(true);
                break;
            case Utils.DEFAULT:
                rbDefault.setChecked(true);
                break;
        }

        rbGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                SharedPreferences.Editor editor = pref.edit();
                //   RadioButton rbSelected = (RadioButton) radioGroup.findViewById(i);
                switch (i) {

                    case R.id.rbRed:
                        editor.putInt("SETTINGS_THEME_COLOR", Utils.RED);
                        Utils.changeToTheme(SettingsActivity.this, Utils.RED);
                        break;
                    case R.id.rbGreen:
                        editor.putInt("SETTINGS_THEME_COLOR", Utils.GREEN);
                        Utils.changeToTheme(SettingsActivity.this, Utils.GREEN);
                        break;
                    case R.id.rbBlue:
                        editor.putInt("SETTINGS_THEME_COLOR", Utils.BLUE);
                        Utils.changeToTheme(SettingsActivity.this, Utils.BLUE);
                        break;

                    default:
                        //rbDefault.setChecked(true);
                        editor.putInt("SETTINGS_THEME_COLOR", Utils.DEFAULT);
                        Utils.changeToTheme(SettingsActivity.this, Utils.DEFAULT);
                        break;

                }
                editor.commit();
            }
        });


    }//FIM DO Método onCreate()


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_personalizado, menu);
        return super.onCreateOptionsMenu(menu);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.btn_menu_checked:


                SharedPreferences pref = getSharedPreferences("NomeDoArquivoPreferences", Context.MODE_PRIVATE);

                SharedPreferences.Editor editor = pref.edit();
                editor.putInt("SETTINGS_THEME_COLOR", colorTheme);
                editor.commit();


                finish();
        }
        return super.onOptionsItemSelected(item);
    }

} //FIM DA CLASSE SettingsActivity
