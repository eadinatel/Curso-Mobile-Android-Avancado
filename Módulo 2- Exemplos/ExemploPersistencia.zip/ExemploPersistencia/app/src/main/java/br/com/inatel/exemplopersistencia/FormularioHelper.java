package br.com.inatel.exemplopersistencia;

import android.view.View;
import android.widget.EditText;

import br.com.inatel.exemplopersistencia.modelo.Contato;

/**
 * Created by rafael.liberato on 16/02/2017.
 */

public class FormularioHelper {

    private final EditText txtPassword, txtNome, txtTelefone, txtEndereco, txtEmail;
    private Contato contato;

    public FormularioHelper(FormularioActivity activity) {
        txtPassword = (EditText) activity.findViewById(R.id.txt_Pass_Form);
        txtEmail = (EditText) activity.findViewById(R.id.txtEmail);
        txtNome = (EditText) activity.findViewById(R.id.txtNome);
        txtTelefone = (EditText) activity.findViewById(R.id.txtTelefone);
        txtEndereco = (EditText) activity.findViewById(R.id.txtEndereco);

        contato = new Contato();
    }

    public Contato getContato() {
        contato.setNome(txtNome.getText().toString());
        contato.setEndereco(txtEndereco.getText().toString());
        contato.setTelefone(txtTelefone.getText().toString());
        contato.setEmail(txtEmail.getText().toString());

        if(txtPassword.getVisibility() == View.VISIBLE)
            contato.setPassword(Integer.valueOf(txtPassword.getText().toString()));

        return contato;
    }

    public void preencheFormulario(Contato contato) {
        txtNome.setText(contato.getNome());
        txtEndereco.setText(contato.getEndereco());
        txtTelefone.setText(contato.getTelefone());
        txtEmail.setText(contato.getEmail());
        txtPassword.setText(String.valueOf(contato.getPassword()));
        this.contato = contato;
    }

    public void setVisibilityField(int visible) {
        txtPassword.setVisibility(visible);
        txtPassword.setHint("Password");
    }
}
