package br.com.inatel.exemplopersistencia;

import android.app.Activity;
import android.content.Intent;

/**
 * Created by rafael.liberato on 20/02/2017.
 */

public class Utils {

    public final static int RED = 0;
    public final static int GREEN = 1;
    public final static int BLUE = 2;
    public final static int DEFAULT = 3;
    private static int themeApplication;


    public static void setTheme(int t){
        themeApplication = t;
    }

    public static void changeToTheme(Activity activity, int theme)
    {
        themeApplication = theme;
        activity.finish();
        activity.startActivity(new Intent(activity, activity.getClass()));
    }


    public static void onActivityCreateSetTheme(Activity activity)
    {
        switch (themeApplication)
        {
             case RED:
                activity.setTheme(R.style.AppThemeRed);
                break;
            case GREEN:
                activity.setTheme(R.style.AppThemeGreen);
                break;
            case BLUE:
                activity.setTheme(R.style.AppThemeBlue);
                break;
            case DEFAULT:
                activity.setTheme(R.style.AppTheme);
        }

    }
}
