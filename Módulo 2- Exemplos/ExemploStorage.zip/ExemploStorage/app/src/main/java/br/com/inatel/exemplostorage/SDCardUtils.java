package br.com.inatel.exemplostorage;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;

/**
 * Created by rafael.liberato on 03/08/2016.
 */
public class SDCardUtils {

    /**
     * Cria um arquivo privado na raiz do sdcard
     *
     * @param context
     * @param fileName
     * @param type     @param type DIRECTORY_MUSIC, DIRECTORY_PODCASTS, DIRECTORY_RINGTONES, DIRECTORY_ALARMS, DIRECTORY_NOTIFICATIONS, DIRECTORY_PICTURES, DIRECTORY_MOVIES, DIRECTORY_DOWNLOADS
     * @return
     */
    public static File getPrivateFile(Context context, String fileName, String type) {
        File sdCardDir = context.getExternalFilesDir(type);
        return createFile(sdCardDir, fileName);
    }

    /**
     * Cria o arquivo no SDCard na pasta informada.
     *
     * @param sdCardDir Pasta do sdcard
     * @param fileName  Nome do arquivo
     * @return
     */
    private static File createFile(File sdCardDir, String fileName) {
        if (!sdCardDir.exists()) {
            sdCardDir.mkdir(); // Cria o diretório se não existe
        }
        // Retorna o arquivo para ler ou salvar no sd card
        File file = new File(sdCardDir, fileName);
        return file;
    }




}
