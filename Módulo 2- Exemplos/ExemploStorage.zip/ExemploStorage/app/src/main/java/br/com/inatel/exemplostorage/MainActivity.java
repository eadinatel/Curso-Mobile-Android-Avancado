package br.com.inatel.exemplostorage;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;

public class MainActivity extends AppCompatActivity {

    private EditText txtNome, txtIdade;
    private Button btnGravarInterno, btnLerInterno, btnGravarExterno, btnLerExterno;
    private static final String nomeArquivoInterno = "MeuArquivoInterno.txt";
    private static final String nomeArquivoExterno = "MeuArquivoExterno.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNome = (EditText) findViewById(R.id.txtNome);
        txtIdade = (EditText) findViewById(R.id.txtIdade);

        btnGravarInterno = (Button) findViewById(R.id.btnGravarInterno);
        btnLerInterno = (Button) findViewById(R.id.btnLerInterno);
        btnGravarExterno = (Button) findViewById(R.id.btnGravarExterno);
        btnLerExterno = (Button) findViewById(R.id.btnLerExterno);

        btnGravarInterno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gravarDadosInterno();
            }
        });

        btnLerInterno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lerDadosInterno();
            }
        });

        btnGravarExterno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gravarDadosExterno();
            }
        });

        btnLerExterno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lerDadosExterno();
            }
        });
    }

    private void gravarDadosExterno() {
        File f = SDCardUtils.getPrivateFile(getApplicationContext(), nomeArquivoExterno, Environment.DIRECTORY_DOWNLOADS);
        IOUtils.writeString(f, getValue());
        Toast.makeText(getApplicationContext(), "Arquivo gravado externamente com sucesso!", Toast.LENGTH_LONG).show();
    }

    private void lerDadosExterno() {
        File file = SDCardUtils.getPrivateFile(getApplicationContext(), nomeArquivoExterno, Environment.DIRECTORY_DOWNLOADS);
        Toast.makeText(getApplicationContext(), "DADOS EXTERNOS \n" + IOUtils.readString(file), Toast.LENGTH_SHORT).show();
    }


    private void gravarDadosInterno() {
        File file = FileUtils.getFile(getApplicationContext(), nomeArquivoInterno);
        IOUtils.writeString(file, getValue());
        Toast.makeText(getApplicationContext(), "Arquivo gravado internamente com sucesso!", Toast.LENGTH_LONG).show();
    }


    private void lerDadosInterno() {

        File file = FileUtils.getFile(getApplicationContext(), nomeArquivoInterno);
        Toast.makeText(getApplicationContext(), "DADOS INTERNOS \n" + IOUtils.readString(file), Toast.LENGTH_SHORT).show();
    }

    private String getValue() {
        String texto = "NOME:" + txtNome.getText().toString() + " IDADE:" + txtIdade.getText().toString();
        return texto;
    }

}
