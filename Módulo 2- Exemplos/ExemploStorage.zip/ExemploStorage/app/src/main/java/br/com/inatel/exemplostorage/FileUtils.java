package br.com.inatel.exemplostorage;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by rafael.liberato on 03/08/2016.
 */
public class FileUtils {

       public static File getFile(Context context, String name) {
        File file = context.getFileStreamPath(name);
        return file;
    }

}
