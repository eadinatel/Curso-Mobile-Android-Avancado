<?php
 
/*
 * All database connection variables
 */
 error_reporting (E_ALL & ~ E_NOTICE & ~ E_DEPRECATED);
define('DB_USER', "u705663560_inate"); // db user
define('DB_PASSWORD', "ead_inatel"); // db password (mention your db password here)
define('DB_DATABASE', "u705663560_avanc"); // database name
define('DB_SERVER', "mysql.hostinger.com.br"); // db server
?>