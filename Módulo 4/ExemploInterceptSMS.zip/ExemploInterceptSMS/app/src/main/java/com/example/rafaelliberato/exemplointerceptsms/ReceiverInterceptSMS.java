package com.example.rafaelliberato.exemplointerceptsms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by rafael.liberato on 17/05/2017.
 */

public class ReceiverInterceptSMS extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {


        Bundle bundle = intent.getExtras();

        try {

            if (bundle != null) {

                final Object[] pdusObj = (Object[]) bundle.get("pdus");

                if (pdusObj != null) {
                    SmsMessage currentMessage;

                    SmsMessage[] msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent);
                    currentMessage = msgs[0];

                    String message = currentMessage.getDisplayMessageBody();

                    Toast.makeText(context, message, Toast.LENGTH_LONG).show();

                }
            }
        } catch (Exception e) {
            Log.e("Exception Intercept SMS", "Erro: " + e);
        }

    }
}
