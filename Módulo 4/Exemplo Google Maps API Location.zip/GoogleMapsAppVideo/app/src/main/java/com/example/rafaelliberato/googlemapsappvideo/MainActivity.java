package com.example.rafaelliberato.googlemapsappvideo;


import android.*;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rafaelliberato.googlemapsappvideo.directions_utils.DirectionFinder;
import com.example.rafaelliberato.googlemapsappvideo.directions_utils.DirectionFinderListener;
import com.example.rafaelliberato.googlemapsappvideo.directions_utils.Route;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener, DirectionFinderListener {


    private GoogleMap mMap;
    private GoogleApiClient mGoogleApiClient;
    Location mLastLocation;
    Marker mCurrLocationMarker;
    LocationRequest mLocationRequest;

    private Button btnDirection;
    private EditText txtOrigem, txtDestino;
    private TextView txtTempo, txtDistancia;


    private List<Marker> marcadoresOrigem = new ArrayList<>();
    private List<Marker> marcadoresDestino = new ArrayList<>();
    private List<Polyline> polylinePaths = new ArrayList<>();
    private ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        btnDirection = (Button) findViewById(R.id.btnDirection);
        txtOrigem = (EditText) findViewById(R.id.txtOrigem);
        txtDestino = (EditText) findViewById(R.id.txtDestino);
        txtTempo = (TextView) findViewById(R.id.txtTempo);
        txtDistancia = (TextView) findViewById(R.id.txtDistancia);

        btnDirection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Enviar Requisição
                sendRequestDirections();

            }
        });


    }

    private void sendRequestDirections() {

        String origem = txtOrigem.getText().toString();
        String destino = txtDestino.getText().toString();
        if (origem.isEmpty()) {
            Toast.makeText(this, "Por favor, digite o endereço de origem!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (destino.isEmpty()) {
            Toast.makeText(this, "Por favor, digite o endereço de destino!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            new DirectionFinder(this, origem, destino, getApplicationContext()).execute();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        checkPermission();
        buildGoogleApiClient();

        //  LatLng pointMarker = new LatLng(21 , 57);
        //   Marker myMarker = googleMap.addMarker(new MarkerOptions()
        //    .position(mMap.getMyLocation().getLatitude(), mMap.getMyLocation().getLongitude()).title("EAD INATEL"));


    }

    private void buildGoogleApiClient() {

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }


    private void checkPermission() {

        //Verificação da permissão
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.ACCESS_FINE_LOCATION)) {

                alertPermission();

            } else {
                // Solicita a permissão
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 0);
            }
        } else {
            // Tudo OK, usuário já deu permissão
            mMap.setMyLocationEnabled(true);

        }
    } //Fim do método CheckPermission

    private void alertPermission() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.app_name).setMessage("Para utilizar este aplicativo, você precisa aceitar as permissões.");
        // Add the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 0);
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }//FIM DO alertPermission()


    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);

        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }
    }

    @Override
    public void onConnectionSuspended(int i) {
        //Callback de conexão suspensa, algum erro ocorre durante a conexão.
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        //Callback de Falha na conexão, algum erro ocorre antes da inicialização da conexão
    }

    @Override
    public void onLocationChanged(Location location) {
        mLastLocation = location;
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }


        //Localização do marcador no mapa
        LatLng latLng = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("EAD INATEL");
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW));
        //Para definir uma imagem como marcador, basta indicar o id do recurso
        // markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_launcher));

        mCurrLocationMarker = mMap.addMarker(markerOptions);


        //Move a Camera para o ponto
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(11));

        //Para com a atualização de localização
        if (mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }
    }

    @Override
    public void onDirectionFinderStart() {

        progressDialog = ProgressDialog.show(this, "Por favor aguarde.",
                "Procurando direção...!", true);

        if (marcadoresOrigem != null) {
            for (Marker marker : marcadoresOrigem) {
                marker.remove();
            }
        }

        if (marcadoresDestino != null) {
            for (Marker marker : marcadoresDestino) {
                marker.remove();
            }
        }

        if (polylinePaths != null) {
            for (Polyline polyline : polylinePaths) {
                polyline.remove();
            }
        }

    }

    @Override
    public void onDirectionFinderSuccess(List<Route> routes) {
        progressDialog.dismiss();
        polylinePaths = new ArrayList<>();
        marcadoresOrigem = new ArrayList<>();
        marcadoresDestino = new ArrayList<>();

        for (Route route : routes) {
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(route.startLocation, 16));
            txtTempo.setText(route.duration.text);
            txtDistancia.setText(route.distance.text);

            marcadoresOrigem.add(mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.start_blue))
                    .title(route.startAddress)
                    .position(route.startLocation)));
            marcadoresDestino.add(mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.end_green))
                    .title(route.endAddress)
                    .position(route.endLocation)));

            PolylineOptions polylineOptions = new PolylineOptions().
                    geodesic(true).
                    color(Color.BLUE).
                    width(10);

            for (int i = 0; i < route.points.size(); i++)
                polylineOptions.add(route.points.get(i));

            //  polylinePaths.add(mMap.addPolyline(polylineOptions));
            mMap.addPolyline(polylineOptions);
        }

    }
}
