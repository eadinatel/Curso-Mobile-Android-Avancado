package com.example.rafaelliberato.exemplojsonnativo;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rafael.liberato on 20/04/2017.
 */

public class HttpUtilsAsync extends AsyncTask<String, String, String> {


    InputStream is = null;
    String result;
    private ProgressDialog progressDialog;
    private Context context;

    public AsyncResponse delegate; // Resposta do processamento para a MainActivity


    public HttpUtilsAsync(Context context) {
        this.context = context;
        this.delegate = (AsyncResponse) context;
    }


    public String create_Request(String url, String method,
                                 List<NameValuePair> params) {


        // Realiza um HTTP request
        try {
            HttpResponse httpResponse = null;
            final DefaultHttpClient httpClient = new DefaultHttpClient();

            //Checagem do tipo de método POST ou GET
            if (method == "POST") {
                // método de requisição do tipo POST

                final HttpPost httpPost = new HttpPost(url);
                httpPost.setEntity(new UrlEncodedFormEntity(params));
                httpResponse = httpClient.execute(httpPost);

            } else if (method == "GET") {
                // método de requisição do tipo GET

                String paramString = URLEncodedUtils.format(params, "utf-8");
                url += "?" + paramString;
                final HttpGet httpGet = new HttpGet(url);
                httpResponse = httpClient.execute(httpGet);
            }

            HttpEntity httpEntity = httpResponse.getEntity();
            is = httpEntity.getContent();
            result = convertInputStreamToString(is);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // retorna uma string
        return result;

    }


    // converte inputstream to String
    private String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while ((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();


        return result;

    }


    @Override
    protected String doInBackground(String... params) {

        List<NameValuePair> list = new ArrayList<>();
        //   list.add(new BasicNameValuePair(params[2], params[3]));
        //    list.add(new BasicNameValuePair(params[4], params[5]));

        result = create_Request(params[0], params[1], list);

        return result;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();


        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Processando Requisição....");
        progressDialog.setTitle("HTTP REQUEST");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
    }


    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        progressDialog.dismiss();

        delegate.processFinish(s);
    }


    public interface AsyncResponse {
        void processFinish(String output);
    }


}


