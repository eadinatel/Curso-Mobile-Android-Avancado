package com.example.rafaelliberato.exemplojsonnativo;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity implements HttpUtilsAsync.AsyncResponse {

    private EditText txtCEP;
    private TextView txtCidade;
    private Button btnConsulta;
    private String URL_BASE = "https://viacep.com.br/ws/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCEP = (EditText) findViewById(R.id.txtCEP);
        txtCidade = (TextView) findViewById(R.id.txtCidade);
        btnConsulta = (Button) findViewById(R.id.btnConsultar);

        btnConsulta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String URL = URL_BASE + txtCEP.getText().toString() + "/json/";

                new HttpUtilsAsync(MainActivity.this).execute(URL, "GET"); //Uma AsyncTask pode ser executada uma única vez

            }
        });
    }

    @Override
    public void processFinish(final String output) {

        final Dados cidade = new Dados();

        JSONObject cidadeObject = null;
        try {
            cidadeObject = new JSONObject(output);
            cidade.setLocalidade(cidadeObject.getString("localidade"));
            cidade.setUf(cidadeObject.getString("uf"));
            cidade.setIbge(cidadeObject.getString("ibge"));
            txtCidade.setText("CIDADE: " + cidade.getLocalidade() + "\nESTADO: " + cidade.getUf());
            Log.d("JSON", "Finalização do Processo");

        } catch (JSONException e) {
            Toast.makeText(MainActivity.this,
                    "Não foi possível identificar o CEP:\nRede de Dados sem Conexão ou \nCEP digitado  inválido.",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }


    }

}
