package com.example.rafaelliberato.projetodetestesead;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

/**
 * Created by rafael.liberato on 03/05/2017.
 */

public class ViewerTokenIdFirebase extends FirebaseInstanceIdService {

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        // Get updated InstanceID token.
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d("Token Firebase", refreshedToken);

        // De posse do ID, o desenvolvedor pode optar por enviar o Token para algum servidor de assinaturas
        // para receber notificações importantes.
        // Neste caso, basta criar um método para enviar as informações, conforme o método de exemplo abaixo
        //
        // sendRegistrationToServer(refreshedToken);
    }
}
