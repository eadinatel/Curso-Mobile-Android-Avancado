package com.example.rafaelliberato.projetodetestesead;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends AppCompatActivity {


    private CheckBox cbkNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cbkNotification = (CheckBox) findViewById(R.id.cbkNotification);
        cbkNotification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked){
                    FirebaseMessaging.getInstance().subscribeToTopic("smart_home");
                    Log.d("Firebase", "Assinatura do tópico smart_home");
                }else{
                    FirebaseMessaging.getInstance().unsubscribeFromTopic("smart_home");
                    Log.d("Firebase", "Remoção da assinatura do tópico smart_home");
                }


            }
        });


//        runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                new ViewerTokenIdFirebase().onTokenRefresh();
//            }
//        });

    } //Final do método onCreate()

}//Final da classe MainActivity
