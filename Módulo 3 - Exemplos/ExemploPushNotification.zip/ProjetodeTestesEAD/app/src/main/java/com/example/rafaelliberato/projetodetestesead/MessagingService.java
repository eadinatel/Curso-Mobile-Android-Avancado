package com.example.rafaelliberato.projetodetestesead;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;



public class MessagingService extends FirebaseMessagingService {

    private static final String TAG = "Mensagem Firebase";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {


        Log.d(TAG, "From: " + remoteMessage.getFrom());

        Map<String, String> data = remoteMessage.getData();

        // Verifica se existem dados na mensagem.
        if (!data.isEmpty()) {
            Log.d(TAG, "Message data payload: " + data);
            Log.d(TAG, "Parametro 1: " + data.get("param1"));
            Log.d(TAG, "Parametro 2: " + data.get("param2"));
        }

        //Verifique se a notificação contem alguma mensagem dentro da notificação.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }


    }
}
