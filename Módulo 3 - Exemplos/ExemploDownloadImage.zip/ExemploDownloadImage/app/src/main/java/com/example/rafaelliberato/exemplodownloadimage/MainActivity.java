package com.example.rafaelliberato.exemplodownloadimage;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private Button btnDownload;
    private ImageView imgPrincipal;
    private String imageURL = "https://cdn.pixabay.com/photo/2016/11/30/12/29/wall-e-1872683_960_720.jpg";
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnDownload = (Button) findViewById(R.id.btnDownload);
        imgPrincipal = (ImageView) findViewById(R.id.imgPrincipal);

        btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DownloadImageTask().execute(imageURL);
                //Invocar o AsyncTask.execute()
            }
        });
    } // Fechamento do método onCreate

    private class DownloadImageTask extends AsyncTask<String , Void, Bitmap> {



        @Override
        protected void onPreExecute() {
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Carregando Imagem, por favor aguarde!");
            progressDialog.show();
        }



        @Override
        protected Bitmap doInBackground(String... params) {

            String urldisplay = params[0];
            Bitmap imgBitmap = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                imgBitmap = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return imgBitmap;
        }


        protected void onPostExecute(Bitmap result) {
            progressDialog.dismiss();
            imgPrincipal.setImageBitmap(result);
        }
    }
}



