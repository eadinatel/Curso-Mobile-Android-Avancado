package com.example.rafaelliberato.exemplocontadorandroid;

import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private Button btnStart, btnStop;
    private TextView txtContador;
    private int count = 0;
    private static boolean STATUS_CONTADOR = false; //True - ativa a contagem , False - desativa a contagem
    private Thread threadStart;
    private Handler handler = new Handler();
    private int myInterval = 1000; //1 seg

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btnStart = (Button) findViewById(R.id.btnStart);
        btnStop = (Button) findViewById(R.id.btnStop);
        txtContador = (TextView) findViewById(R.id.txtContador);


        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startTask();
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            stopTask();
            }
        });


    }

    private void stopTask() {
      handler.removeCallbacks(runnable);
    }

    Runnable runnable = new Runnable() {
        @Override
        public void run() {

            try{
                count++;
                txtContador.setText(count+"s");
                Log.d("TAG_TIME", "TIME: " + SystemClock.uptimeMillis());

            }
            finally {
                handler.postDelayed(runnable, myInterval);
            }
        }
    };

    private void startTask() {
        handler.postDelayed(runnable,myInterval);

    }
}
