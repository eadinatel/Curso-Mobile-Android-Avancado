package br.com.inatel.fragments_curso;


import android.app.Activity;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.media.Image;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import br.com.inatel.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class Dinamico extends Fragment {

    private TextView txtItemSelected;
    private ImageView imgItemSelected;
    private Activity activity;

    public Dinamico() {
        // Required empty public constructor
    }

    public void onAttach(Activity activity){
        super.onAttach(activity);
        this.activity = activity;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        txtItemSelected = (TextView) activity.findViewById(R.id.txtItemSelected);
        imgItemSelected = (ImageView) activity.findViewById(R.id.imgItemSelected);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_dinamico, container, false);

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_dinamico, container, false);
    }

    public void atualizaView(int position) {

        Resources res = getResources();
        String[] titulo = res.getStringArray(R.array.titulos);
        txtItemSelected.setText(titulo[position]);

        TypedArray imgs = res.obtainTypedArray(R.array.res_id);
        imgItemSelected.setImageResource(imgs.getResourceId(position, -1));

    }
}
