package br.com.inatel.recyclerview_curso;

import android.media.Image;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import br.com.inatel.R;

/**
 * Created by rafael.liberato on 18/07/2016.
 */
public class ViewHolderCurso extends RecyclerView.ViewHolder {

    final TextView nomeCurso;
    final ImageView imgCurso;


    public ViewHolderCurso(View view) {
        super(view);
        nomeCurso = (TextView) view.findViewById(R.id.txtCourseName);
        imgCurso = (ImageView) view.findViewById(R.id.imgCourseImage);
        // restante das buscas caso a lista tenha mais itens
    }
}
