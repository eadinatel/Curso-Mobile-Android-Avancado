package br.com.inatel.recyclerview_curso;

/**
 * Created by rafael.liberato on 18/07/2016.
 */
public class Curso {

        private String nome;
        private int resIDImage;

        public Curso(String nome, int resIDImage){
            this.nome = nome;
            this.resIDImage = resIDImage;
        }


        public String getName(){
            return nome;
        }

        public int getResIDImage(){
            return resIDImage;
        }


}
