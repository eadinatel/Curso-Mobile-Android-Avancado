package br.com.inatel.recyclerview_curso;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import br.com.inatel.R;

/**
 * Created by rafael.liberato on 18/07/2016.
 */
public class AdapterRecyclerViewCurso extends RecyclerView.Adapter {

    private ArrayList<Curso> listaCursos;
    private Context context;
    private CursoOnClickListener cursoOnClickListener;


    public AdapterRecyclerViewCurso(ArrayList<Curso> cursos, Context context, CursoOnClickListener listenerCurso) {

        this.listaCursos = cursos;
        this.context = context;
        this.cursoOnClickListener = listenerCurso;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_course, parent, false);
        ViewHolderCurso holder = new ViewHolderCurso(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        ViewHolderCurso holderCurso = (ViewHolderCurso) holder;

        Curso curso = listaCursos.get(position);

        holderCurso.nomeCurso.setText(curso.getName());
        holderCurso.imgCurso.setImageResource(curso.getResIDImage());


        if(listaCursos != null){

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cursoOnClickListener.onClickCurso(holder.itemView, position);
                }
            });
        }


    }

    @Override
    public int getItemCount() {
        return listaCursos.size();
    }

    public interface CursoOnClickListener {
         void onClickCurso(View view, int index);
    }
}
