package br.com.inatel;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import br.com.inatel.fragments_curso.Dinamico;

public class MainActivity extends AppCompatActivity implements Comunicador{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public void enviaPosicaoItem(int position) {
        FragmentManager manager= getSupportFragmentManager();
        Dinamico fragDinamico = (Dinamico) manager.findFragmentById(R.id.fragmentDinamico);
        fragDinamico.atualizaView(position);
    }
}
