package br.com.inatel.fragments_curso;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import java.util.ArrayList;

import br.com.inatel.Comunicador;
import br.com.inatel.R;
import br.com.inatel.recyclerview_curso.AdapterRecyclerViewCurso;
import br.com.inatel.recyclerview_curso.Curso;


/**
 * A simple {@link Fragment} subclass.
 */
public class Estatico extends Fragment implements AdapterRecyclerViewCurso.CursoOnClickListener {

    private Comunicador comunicador;
    private ArrayList<Curso> listaCursos;
    private AdapterRecyclerViewCurso myAdapter;
    private RecyclerView myRecyclerView;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        comunicador = (Comunicador) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        gerarCursos();
       //VINCULANDO RECYCLER VIEW
        View rootView = inflater.inflate(R.layout.fragment_estatico, container, false);

        myRecyclerView = (RecyclerView) rootView.findViewById(R.id.myRecycler);

        myAdapter = new AdapterRecyclerViewCurso(listaCursos, getActivity().getBaseContext(), this);

        myRecyclerView.setAdapter(myAdapter);
        //DEFINI O ESTILO DO RECYCLERVIEW com o LayoutManager.
        myRecyclerView.setItemAnimator(new DefaultItemAnimator());
        myRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Inflate the layout for this fragment
        return rootView;
    }

    private void gerarCursos() {
        listaCursos = new ArrayList<Curso>();
        listaCursos.add(new Curso("DESENVOLVIMENTO MOBILE", R.drawable.icon_ead_mobile));
        listaCursos.add(new Curso("SATELITE", R.drawable.icon_ead_satelite));
        listaCursos.add(new Curso("TV DIGITAL", R.drawable.icon_ead_tv_digital));
        listaCursos.add(new Curso("WEB", R.drawable.icon_ead_web));
    }

    @Override
    public void onClickCurso(View view, int index) {
        comunicador.enviaPosicaoItem(index);
    }
}
