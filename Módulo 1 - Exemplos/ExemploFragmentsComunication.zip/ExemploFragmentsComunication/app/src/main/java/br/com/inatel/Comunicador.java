package br.com.inatel;

/**
 * Created by rafael.liberato on 18/07/2016.
 */
public interface Comunicador {

     void enviaPosicaoItem(int position);
}
